import React, { useEffect, useState } from 'react';
import { CalendarDays } from 'lucide-react';
import { motion } from 'framer-motion';
import GlassCard from '@/components/shared/GlassCard';
import { masterService } from '@/lib/master';
import { copyLogService } from '@/lib/copyLogs';
import { useToast } from '@/components/shared/Toast';

const formatDate = (d) => {
  if (!d) return 'N/A';
  return new Date(d).toLocaleString('en-IN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};

const Logs = () => {
  const { addToast } = useToast();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchLogs = async () => {
      setLoading(true);
      try {
        const data = await masterService.getCopyLogs();
        setLogs(Array.isArray(data) ? data : data.logs || []);
      } catch (error) {
        try {
          const fallback = await copyLogService.getAll();
          setLogs(Array.isArray(fallback) ? fallback : fallback.logs || []);
        } catch (fallbackError) {
          addToast(fallbackError.message || error.message, 'error');
        }
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, [addToast]);

  const filteredLogs = logs.filter((log) =>
    !search ||
    log.symbol?.toLowerCase().includes(search.toLowerCase()) ||
    log.childId?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-purple"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold sm:text-2xl">Copy Logs</h1>
          <p className="text-sm text-muted-foreground">Track trade execution across children</p>
        </div>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search Symbol or Child ID"
          className="w-full sm:w-64 bg-black/5 dark:bg-white/5 border border-border rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-brand-purple placeholder:text-muted-foreground/40"
        />
      </div>

      <GlassCard noPadding>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border/50 bg-black/5 dark:bg-white/5">
                {[
                  'Symbol',
                  'Qty',
                  'Trade Type',
                  'Master Status',
                  'Child Status',
                  'Trade Ref',
                  'Error',
                  'Date',
                ].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log, idx) => (
                  <motion.tr
                    key={log.id || idx}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: idx * 0.02 }}
                    className="border-b border-border/30 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                  >
                    <td className="px-4 py-3 font-semibold text-sm">
                      {log.symbol || 'N/A'}
                    </td>
                    <td className="px-4 py-3 text-sm">{log.qty || 0}</td>
                    <td className="px-4 py-3 text-xs uppercase text-muted-foreground">
                      {log.tradeType || 'N/A'}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          log.masterStatus === 'COMPLETE'
                            ? 'bg-green-500/10 text-green-500'
                            : 'bg-yellow-500/10 text-yellow-500'
                        }`}
                      >
                        {log.masterStatus || 'PENDING'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          log.childStatus === 'COMPLETE'
                            ? 'bg-green-500/10 text-green-500'
                            : log.childStatus === 'FAILED'
                            ? 'bg-red-500/10 text-red-500'
                            : 'bg-yellow-500/10 text-yellow-500'
                        }`}
                      >
                        {log.childStatus || 'PENDING'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground">
                      {log.masterTradeId || '—'}
                    </td>
                    <td className="px-4 py-3 text-xs text-danger max-w-[180px] truncate" title={log.errorMessage || ''}>
                      {log.errorMessage || '—'}
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">
                      {formatDate(log.createdAt)}
                    </td>
                  </motion.tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-muted-foreground">
                    <CalendarDays className="w-10 h-10 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No copy logs found</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
};

export default Logs;
